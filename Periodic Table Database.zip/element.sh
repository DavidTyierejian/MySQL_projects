#!/bin/bash
# Chore comment so i can meet the commit requirement
PSQL="psql --username=freecodecamp --dbname=periodic_table --no-align --tuples-only -c"

# Function to get element information from the database
get_element_info() {
  local ELEMENT=$1
  $PSQL "SELECT elements.atomic_number, elements.symbol, elements.name, properties.atomic_mass, properties.melting_point_celsius, properties.boiling_point_celsius, types.type
         FROM elements
         JOIN properties ON elements.atomic_number = properties.atomic_number
         JOIN types ON properties.type_id = types.type_id
         WHERE elements.atomic_number::text = '$ELEMENT' OR elements.symbol = '$ELEMENT' OR elements.name = '$ELEMENT';"
}

# Main script logic
main() {
  if [ -z "$1" ]; then
    echo "Please provide an element as an argument."
    exit 0
  fi

  ELEMENT_INFO=$(get_element_info "$1")

  if [ -z "$ELEMENT_INFO" ]; then
    echo "I could not find that element in the database."
    exit 0
  fi

  IFS='|' read -r ATOMIC_NUMBER SYMBOL NAME ATOMIC_MASS MELTING_POINT BOILING_POINT TYPE <<< "$ELEMENT_INFO"

  echo "The element with atomic number $ATOMIC_NUMBER is $NAME ($SYMBOL). It's a $TYPE, with a mass of $ATOMIC_MASS amu. $NAME has a melting point of $MELTING_POINT celsius and a boiling point of $BOILING_POINT celsius."
}

# Call the main function with the provided argument
main "$1"
